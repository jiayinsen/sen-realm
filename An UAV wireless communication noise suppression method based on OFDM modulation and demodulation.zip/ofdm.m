clear all;
clc;
%fs=40000;%����Ƶ��
f1=4e3;   %������4000��f1=4e3���������ڴ˳���ָ���ǲ���Ƶ�ʵĴ��䣿
f2=64e3;%��׼UART����ѡ16������,Ҳ����ѡ64������,���˾���Ӧ���Ƿ����Ƶ���.
phi=0;
jg=f2/f1;
jg2=jg/2;
a=1;
i1=1;
i2=1;
i3=1;
i4=1;


tu = imread('C:\Users\dell\Desktop\timg.jpg'); 
x=rgb2gray(tu);
% figure
% imshow(x);
% title('ԭʼͼ��')
thresh1 = graythresh(x);
tu2 = im2bw(x,thresh1);
new=(im2double(tu2).*2-1); 

indata=reshape(new,1,[]);
% indata=randsrc(1,2560,[1,-1]);
p=length(indata);


%�����任
for i=1:1:p;
if rem(i,2)==1
    I(i1)=indata(i);
    i1=i1+1;
end
if rem(i,2)==0
    Q(i2)=indata(i);
    i2=i2+1;
end
end

%����
t=1/f2:1/f2:(p*jg2)/f2;
zaibo1=a*cos(2*pi*f1*t-phi);
data1=kron(I,ones(1,jg));
data111=data1.*zaibo1;
zaibo2=a*sin(2*pi*f1*t-phi);
data2=kron(Q,ones(1,jg));
data222=data2.*zaibo2;
s=(data111+data222);

% figure
% plot(t,s);
% title('qpsk����ʱ��ͼ��');

%ifft ǰ׺ 
s3 = reshape(s,32,[]);
s4 = ifft(s3,32,1);
s5=[s4(:,end-32+1:end) s4];
s6 = reshape(s5,1,[]);
ofdmd=real(s6);
ofdmx=imag(s6);

fsmin=4000;
fsmax=4000;
step=100;
c=500;
for fs=fsmin:step:fsmax
    fsa((((fs-fsmin)/step)+1))=fs;
tt=1/f2:1/f2:((p*jg2)+1024)/f2;
%inoise=0;
inoise=c*sin(2*pi*fs*tt);%��������
%inoise=c*square(2*pi*fs*tt,50);%��������
%inoise=c*randn(1,length(s6));  % ��˹����
% inoise=c*sawtooth(2*pi*fs*tt,0.5);% ��������

% inoise=0.*ofdmd;%EFT�����򻯺���
% for k=1:5:(((p*jg2)+1024));%BPSK���Ƴ����������ֵ�Ӹ�
% inoise(k)=c;
% end

% inoise=0.*s6;%��ӿ����
% t1=0:1/64e3:158e-6;
% for i=1:length(t1)
%     if t1(i)<=1.2e-6
%         inoise(i)=1*exp(0.481*1e12*(t1(i)^2))-1;
%          inoise(i)=c* inoise(i);
%     else if t1(i)<130e-6
%             inoise(i)=1-1/100*(t1(i)-1.2e-6)*1e6;
%             inoise(i)=c*inoise(i);
%             else if t1(i)>=130e-6
%                    inoise(i)=-1+1/100*(t1(i)-1.2e-6)*1e6-0.576;
%                    inoise(i)=c*inoise(i);
%                 end
%         end
%     end
% end
% for i=11:length(s6);
%     inoise(i)=inoise(i)+inoise(rem(i,11)+1);
% end

 %inoise=inoise+inoise1;
 datanoise=ofdmd+inoise;
 datanoise1=0.7*ofdmd+0.1*inoise;
 
 datanoise3=ofdmx+inoise;
 datanoise4=0.7*ofdmx+0.1*inoise;


 
%ʵ��ICA-------------------------------------------------------------------

s11=datanoise;
s12=datanoise1;

S=[s11;s12];%�ź����5*N
X=S;%�۲��ź�




% figure;
% subplot(2,1,1);plot(X(1,:));title('�۲��źţ�����źţ�');
% subplot(2,1,2);plot(X(2,:));

 
Z=ICA(X);
 
figure;
subplot(3,1,1);plot(Z(1,:));title('������ź�');axis([0 300 -5,5]);
subplot(3,1,2);plot(Z(2,:));title('Դ�ź�');axis([0 300 -5,5]);
subplot(3,1,3);plot(datanoise);title('����ź�');axis([0 300 -210,210]);
datareal=Z(2,:);


% ------------------------------------------------------------------
%�鲿ICA------------------------------------------------------------

s13=datanoise3;
s14=datanoise4;
S=[s13;s14];%�ź����5*N
X=S;%�۲��ź�
Z=ICA(X);

figure;
subplot(3,1,1);plot(Z(1,:));title('������ź�');axis([0 300 -5,5]);
subplot(3,1,2);plot(Z(2,:));title('Դ�ź�');axis([0 300 -5,5]);
subplot(3,1,3);plot(datanoise3);title('����ź�');axis([0 300 -210,210]);
dataimag=Z(2,:);
% ------------------------------------------------------------------
datareturn1=complex(datareal,dataimag);
datareturn2=complex(-1*datareal,dataimag);
datareturn3=complex(-1*datareal,-1*dataimag);
datareturn4=complex(datareal,-1*dataimag);
dataerror=complex(datanoise,datanoise3);

s7 =reshape(datareturn1,32,[]);
s8=[s7(:,33:end)];
s9 = fft(s8,32,1);
s10 = reshape(s9,1,[]);

%���
I1=s10.*zaibo1;
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[b,a]=butter(4,Wc,'low');
I2=filter(b,a,I1);

j=1;
for iii=jg/2:jg:p*jg/2;
    if I2(iii)>=0;
        outdataI(j)=1;
    else if I2(iii)<0;
            outdataI(j)=-1;
        end 
    end
    j=j+1;
end

Q1=s10.*zaibo2;    %Q·
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[d,c]=butter(4,Wc,'low');
Q2=filter(d,c,Q1);

% figure
% plot(t,Q2);
% title('qpsk�˲�ͼ��');
% figure
% plot(s6)

% figure
% plot(tt,datanoise);
% title('ͼ��');
% figure
% plot(tt,inoise);
j=1;
for iii=jg/2:jg:p*jg/2;
    if Q2(iii)>=0;
        outdataQ(j)=1;
    else if Q2(iii)<0;
            outdataQ(j)=-1;
        end 
    end
    j=j+1;
end
i3=1;
i4=1;

for i=1:1:p;      %�����任
if rem(i,2)==1
    outdata(i)=outdataI(i3);
    i3=i3+1;
end
if rem(i,2)==0
    outdata(i)=outdataQ(i4);
    i4=i4+1;
end
end

end
error1=(sum(abs(indata-outdata))/length(indata)/2);
ef(((fs-fsmin)/step)+1)=error1;

set1=reshape(outdata,670,560);

% ----------------------------------------------------------------------------------
s7 =reshape(datareturn2,32,[]);
s8=[s7(:,33:end)];
s9 = fft(s8,32,1);
s10 = reshape(s9,1,[]);

%���
I1=s10.*zaibo1;
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[b,a]=butter(4,Wc,'low');
I2=filter(b,a,I1);

j=1;
for iii=jg/2:jg:p*jg/2;
    if I2(iii)>=0;
        outdataI(j)=1;
    else if I2(iii)<0;
            outdataI(j)=-1;
        end 
    end
    j=j+1;
end

Q1=s10.*zaibo2;    %Q·
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[d,c]=butter(4,Wc,'low');
Q2=filter(d,c,Q1);


j=1;
for iii=jg/2:jg:p*jg/2;
    if Q2(iii)>=0;
        outdataQ(j)=1;
    else if Q2(iii)<0;
            outdataQ(j)=-1;
        end 
    end
    j=j+1;
end
i3=1;
i4=1;

for i=1:1:p;      %�����任
if rem(i,2)==1
    outdata3(i)=outdataI(i3);
    i3=i3+1;
end
if rem(i,2)==0
    outdata3(i)=outdataQ(i4);
    i4=i4+1;
end
end

error2=(sum(abs(indata-outdata3))/length(indata)/2);

set3=reshape(outdata3,670,560);

%-----------------------------------------------------------------------------------
s7 =reshape(datareturn3,32,[]);
s8=[s7(:,33:end)];
s9 = fft(s8,32,1);
s10 = reshape(s9,1,[]);

%���
I1=s10.*zaibo1;
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[b,a]=butter(4,Wc,'low');
I2=filter(b,a,I1);

j=1;
for iii=jg/2:jg:p*jg/2;
    if I2(iii)>=0;
        outdataI(j)=1;
    else if I2(iii)<0;
            outdataI(j)=-1;
        end 
    end
    j=j+1;
end

Q1=s10.*zaibo2;    %Q·
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[d,c]=butter(4,Wc,'low');
Q2=filter(d,c,Q1);


j=1;
for iii=jg/2:jg:p*jg/2;
    if Q2(iii)>=0;
        outdataQ(j)=1;
    else if Q2(iii)<0;
            outdataQ(j)=-1;
        end 
    end
    j=j+1;
end
i3=1;
i4=1;

for i=1:1:p;      %�����任
if rem(i,2)==1
    outdata4(i)=outdataI(i3);
    i3=i3+1;
end
if rem(i,2)==0
    outdata4(i)=outdataQ(i4);
    i4=i4+1;
end
end


error3=(sum(abs(indata-outdata4))/length(indata)/2);
set4=reshape(outdata4,670,560);

%-----------------------------------------------------------------------------------
s7 =reshape(datareturn4,32,[]);
s8=[s7(:,33:end)];
s9 = fft(s8,32,1);
s10 = reshape(s9,1,[]);

%���
I1=s10.*zaibo1;
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[b,a]=butter(4,Wc,'low');
I2=filter(b,a,I1);

j=1;
for iii=jg/2:jg:p*jg/2;
    if I2(iii)>=0;
        outdataI(j)=1;
    else if I2(iii)<0;
            outdataI(j)=-1;
        end 
    end
    j=j+1;
end

Q1=s10.*zaibo2;    %Q·
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[d,c]=butter(4,Wc,'low');
Q2=filter(d,c,Q1);


j=1;
for iii=jg/2:jg:p*jg/2;
    if Q2(iii)>=0;
        outdataQ(j)=1;
    else if Q2(iii)<0;
            outdataQ(j)=-1;
        end 
    end
    j=j+1;
end
i3=1;
i4=1;

for i=1:1:p;      %�����任
if rem(i,2)==1
    outdata5(i)=outdataI(i3);
    i3=i3+1;
end
if rem(i,2)==0
    outdata5(i)=outdataQ(i4);
    i4=i4+1;
end
end


error4=(sum(abs(indata-outdata5))/length(indata)/2);
set5=reshape(outdata5,670,560);

% ----------------------------------------------------------------------------------
s7 =reshape(dataerror,32,[]);
s8=[s7(:,33:end)];
s9 = fft(s8,32,1);
s10 = reshape(s9,1,[]);

%���
I1=s10.*zaibo1;
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[b,a]=butter(4,Wc,'low');
I2=filter(b,a,I1);

j=1;
for iii=jg/2:jg:p*jg/2;
    if I2(iii)>=0;
        outdataI(j)=1;
    else if I2(iii)<0;
            outdataI(j)=-1;
        end 
    end
    j=j+1;
end

Q1=s10.*zaibo2;    %Q·
Wc=3*f1/f2;                                          %��ֹƵ�� 2*f1/f2
[d,c]=butter(4,Wc,'low');
Q2=filter(d,c,Q1);


j=1;
for iii=jg/2:jg:p*jg/2;
    if Q2(iii)>=0;
        outdataQ(j)=1;
    else if Q2(iii)<0;
            outdataQ(j)=-1;
        end 
    end
    j=j+1;
end
i3=1;
i4=1;

for i=1:1:p;      %�����任
if rem(i,2)==1
    outdata2(i)=outdataI(i3);
    i3=i3+1;
end
if rem(i,2)==0
    outdata2(i)=outdataQ(i4);
    i4=i4+1;
end
end


errororigin=(sum(abs(indata-outdata2))/length(indata)/2);
set2=reshape(outdata2,670,560);

%------------------------------------------------------------------------------------------------------


T=t(2)-t(1);
fs1=1/T;
L=length(s);
NFFT=2^nextpow2(L);
Y=fft(s,NFFT)/L;
f=fs1/2*linspace(0,1,NFFT/2+1);
yy=2*abs(Y(1:NFFT/2+1));
% figure
% plot(f,yy)
% title('qpskƵ��');

LL=length(datanoise);
NFFT1=2^nextpow2(LL);
YY=fft(datanoise,NFFT1)/LL;
ff=fs1/2*linspace(0,1,NFFT1/2+1);
yy1=2*abs(YY(1:NFFT1/2+1));

% figure
% plot(ff,yy1)
% title('fftƵ��');

figure
plot(datareal,'b');
hold on
% plot(real(datanoise2),'y')%??????????????????????????????????????????????????
% hold on
plot(ofdmd,'r');axis([0 100 -5,5]);

figure
plot(dataimag);
hold on
plot(ofdmx,'r');axis([0 100 -5,5]);

figure;
subplot(2,3,1);imshow(x);title('ԭʼͼ��');
subplot(2,3,2);imshow(set2);title('������ͼ��');
subplot(2,3,3);imshow(set1);title('ICAͼ1');
subplot(2,3,4);imshow(set3);title('ICAͼ2');
subplot(2,3,5);imshow(set4);title('ICAͼ3');
subplot(2,3,6);imshow(set5);title('ICAͼ4');

figure;
imshow(x);
title('ԭʼͼ��');

figure;
imshow(set2);
title('������ͼ��');

figure;
imshow(set1);
title('ICAͼ1');

figure;
imshow(set3);
title('ICAͼ2');

figure;
imshow(set4);
title('ICAͼ3');

figure;
imshow(set5);
title('ICAͼ4');



