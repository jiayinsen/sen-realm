clear all;
clc;
%fs=40000;%����Ƶ��
f1=4e3;   %������4000��f1=4e3���������ڴ˳���ָ���ǲ���Ƶ�ʵĴ��䣿
f2=64e3;%��׼UART����ѡ16������,Ҳ����ѡ64������,���˾���Ӧ���Ƿ����Ƶ���.
phi=0;
jg=f2/f1;
jg2=jg/2;
a=1;
i1=1;
i2=1;
i3=1;
i4=1;
ditong = 3.05;
jieshu = 4;
i_mark = 1;%Ѱ����ȷ�źŵĸ���ָ��
%�Զ��屨ͷ
baotou = [1 0 0 1 1 1 1 0 0 0 1 1 1 0 1 0 1 0 0 1 1 1 1 0 0 0 1 1 1 0 1 0 1 0 0 1 1 1 1 0 0 0 1 1 1 0 1 0 1 0 0 1 1 1 1 0 0 0 1 1 1 0 1 0];
p_baotou = length(baotou);
baotou_cop = (2*baotou-1);

cplex = [1 1; -1 1; -1 -1; 1 -1];%�ź���λ����������

%------------------------------------------------------------------ͼƬԤ����ģ��
tu = imread('C:\Users\dell\Desktop\timg.jpg'); 
x=rgb2gray(tu);

thresh1 = graythresh(x);
tu2 = im2bw(x,thresh1);

new=(im2double(tu2).*2-1); 
size_1 = size(new);

indata_origin = reshape(new,1,[]);
indata=[baotou indata_origin];%���ӱ�ͷ
% indata=randsrc(1,2560,[1,-1]);
p=length(indata);
%--------------------------------------------------------------------

%---------------------------------------------------------------------qpsk����ģ��

%�����任
for i=1:1:p;
if rem(i,2)==1
    I(i1)=indata(i);
    i1=i1+1;
end
if rem(i,2)==0
    Q(i2)=indata(i);
    i2=i2+1;
end
end

%qpsk����
t=1/f2:1/f2:(p*jg2)/f2;
zaibo1=a*cos(2*pi*f1*t-phi);
data1=kron(I,ones(1,jg));
data111=data1.*zaibo1;
zaibo2=a*sin(2*pi*f1*t-phi);
data2=kron(Q,ones(1,jg));
data222=data2.*zaibo2;
s = (data111+data222); %qpsk����
%-----------------------------------------------------------------------

%------------------------------------------------------------------------ofdm����ģ��

%ifft ǰ׺ 
s3 = reshape(s,32,[]);
s4 = ifft(s3,32,1);
s5=[s4(:,end-32+1:end) s4];
s6 = reshape(s5,1,[]);%ofdm�����ź�
ofdm_real = s6;

ofdmd=real(s6);
ofdmx=imag(s6);
%--------------------------------------------------------------------------

%---------------------------------------------------------------------------��������������ģ��
fsmin=4000;
fsmax=4000;
step=100;
c=500;
for fs=fsmin:step:fsmax
    fsa((((fs-fsmin)/step)+1))=fs;
tt=1/f2:1/f2:((p*jg2)+1024)/f2;
%inoise=0;
inoise=c*sin(2*pi*fs*tt);%��������
%inoise=c*square(2*pi*fs*tt,50);%��������
%inoise=c*randn(1,length(s6));  % ��˹����
%inoise=c*sawtooth(2*pi*fs*tt,0.5);% ��������

% inoise=0.*ofdmd;%EFT�����򻯺���
% for k=1:5:(((p*jg2)+1024));%QPSK���Ƴ����������ֵ�Ӹ�
% inoise(k)=c;
% end

% inoise=0.*s6;%��ӿ����
% t1=0:1/64e3:158e-6;
% for i=1:length(t1)
%     if t1(i)<=1.2e-6
%         inoise(i)=1*exp(0.481*1e12*(t1(i)^2))-1;
%          inoise(i)=c* inoise(i);
%     else if t1(i)<130e-6
%             inoise(i)=1-(t1(i)-1.2e-6)*1e4;
%             inoise(i)=c*inoise(i);
%             else if t1(i)>=130e-6
%                    inoise(i)=-1+(t1(i)-1.2e-6)*1e4-0.570;
%                    inoise(i)=c*inoise(i);
%                 end
%         end
%     end
% end
% for i=11:length(s6);
%     inoise(i)=inoise(i)+inoise(rem(i,11)+1);
% end

end

 datanoise_real = ofdm_real + inoise;
 %inoise=inoise+inoise1;
 datanoise=ofdmd+inoise;
 datanoise1=0.7*ofdmd+0.3*inoise;
 
 datanoise3=ofdmx+inoise;
 datanoise4=0.7*ofdmx+0.3*inoise;
%--------------------------------------------------------------------------------------------

%---------------------------------------------------------------------------------------�źŴ�������������ģ��(ICA��
%ʵ��ICA
s11=datanoise;
s12=datanoise1;

S=[s11;
   s12];%�ź����5*N
X=S;%�۲��ź�


 
Z1=ICA(X);
 
figure;
subplot(4,1,1);plot(Z1(1,:));title('����ź�1��ʵ����');axis([0 300 -5,5]);
subplot(4,1,2);plot(Z1(2,:));title('����ź�2��ʵ����');axis([0 300 -5,5]);
subplot(4,1,3);plot(datanoise);title('����ź�');axis([0 300 -210,210]);
subplot(4,1,4);plot(ofdmd);title('ԭʼʵ���ź�');axis([0 300 -1,1]);
%datareal=Z(2,:);


% --------------------------------------------------------------------------------
%�鲿ICA--------------------------------------------------------------------------

s13=datanoise3;
s14=datanoise4;
S=[s13;
   s14];%�ź����5*N
X=S;%�۲��ź�
Z2=ICA(X);

figure;
subplot(4,1,1);plot(Z2(1,:));title('����ź�1���鲿��');axis([0 300 -5,5]);
subplot(4,1,2);plot(Z2(2,:));title('����ź�2���鲿��');axis([0 300 -5,5]);
subplot(4,1,3);plot(datanoise3);title('����ź�');axis([0 300 -210,210]);
subplot(4,1,4);plot(ofdmx);title('ԭʼ�鲿�ź�');axis([0 300 -1,1]);

%dataimag=Z(2,:);
% --------------------------------------------------------------------------------���������У������λУ��ģ��
for i_zdeofdmd = 1:1:2
    for j_zdeofdmx = 1:1:2
        datareal = Z1(i_zdeofdmd,:);
        dataimag = Z2(j_zdeofdmx,:);
        
        datareturn1=complex(datareal,dataimag);
        datareturn2=complex(-1*datareal,dataimag);
        datareturn3=complex(-1*datareal,-1*dataimag);
        datareturn4=complex(datareal,-1*dataimag);
        dataerror=complex(datanoise,datanoise3);
        
        z_huanyuan_ofdmd(i_zdeofdmd,:) = Z1(i_zdeofdmd,:);
        z_huanyuan_ofdmx(j_zdeofdmx,:) = Z2(j_zdeofdmx,:);
        
        s7 =reshape(datareturn1,32,[]);
        s8=[s7(:,33:end)];
        s9 = fft(s8,32,1);
        s10 = reshape(s9,1,[]);
        
        %���
        I1=s10.*zaibo1;
        Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
        [b,a]=butter(jieshu,Wc,'low');
        I2=filter(b,a,I1);
        
        j=1;
        for iii=jg/2:jg:p*jg/2;
            if I2(iii)>=0;
                outdataI(j)=1;
            else if I2(iii)<0;
                    outdataI(j)=-1;
                end
            end
            j=j+1;
        end
        
        Q1=s10.*zaibo2;    %Q·
        Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
        [d,c]=butter(jieshu,Wc,'low');
        Q2=filter(d,c,Q1);
        
        
        j=1;
        for iii=jg/2:jg:p*jg/2;
            if Q2(iii)>=0;
                outdataQ(j)=1;
            else if Q2(iii)<0;
                    outdataQ(j)=-1;
                end
            end
            j=j+1;
        end
        i3=1;
        i4=1;
        
        for i=1:1:p;      %�����任
            if rem(i,2)==1
                outdata1(i)=outdataI(i3);
                i3=i3+1;
            end
            if rem(i,2)==0
                outdata1(i)=outdataQ(i4);
                i4=i4+1;
            end
        end
        
   
    
    
   % ef(((fs-fsmin)/step)+1)=error1;
    set1_origin = outdata1;
    baotou_demod(1,:) = set1_origin(1,1:p_baotou);
    
    % ----------------------------------------------------------------------------------
    s7 =reshape(datareturn2,32,[]);
    s8=[s7(:,33:end)];
    s9 = fft(s8,32,1);
    s10 = reshape(s9,1,[]);
    
    %���
    I1=s10.*zaibo1;
    Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*f1/f2
    [b,a]=butter(jieshu,Wc,'low');
    I2=filter(b,a,I1);
    
    j=1;
    for iii=jg/2:jg:p*jg/2;
        if I2(iii)>=0;
            outdataI(j)=1;
        else if I2(iii)<0;
                outdataI(j)=-1;
            end
        end
        j=j+1;
    end
    
    Q1=s10.*zaibo2;    %Q·
    Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
    [d,c]=butter(jieshu,Wc,'low');
    Q2=filter(d,c,Q1);
    
    
    j=1;
    for iii=jg/2:jg:p*jg/2;
        if Q2(iii)>=0;
            outdataQ(j)=1;
        else if Q2(iii)<0;
                outdataQ(j)=-1;
            end
        end
        j=j+1;
    end
    i3=1;
    i4=1;
    
    for i=1:1:p;      %�����任
        if rem(i,2)==1
            outdata3(i)=outdataI(i3);
            i3=i3+1;
        end
        if rem(i,2)==0
            outdata3(i)=outdataQ(i4);
            i4=i4+1;
        end
    end
    
    
    set3_origin = outdata3;
    baotou_demod(2,:) = set3_origin(1,1:p_baotou);
    
    %-----------------------------------------------------------------------------------
    s7 =reshape(datareturn3,32,[]);
    s8=[s7(:,33:end)];
    s9 = fft(s8,32,1);
    s10 = reshape(s9,1,[]);
    
    %���
    I1=s10.*zaibo1;
    Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
    [b,a]=butter(jieshu,Wc,'low');
    I2=filter(b,a,I1);
    
    j=1;
    for iii=jg/2:jg:p*jg/2;
        if I2(iii)>=0;
            outdataI(j)=1;
        else if I2(iii)<0;
                outdataI(j)=-1;
            end
        end
        j=j+1;
    end
    
    Q1=s10.*zaibo2;    %Q·
    Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
    [d,c]=butter(jieshu,Wc,'low');
    Q2=filter(d,c,Q1);
    
    
    j=1;
    for iii=jg/2:jg:p*jg/2;
        if Q2(iii)>=0;
            outdataQ(j)=1;
        else if Q2(iii)<0;
                outdataQ(j)=-1;
            end
        end
        j=j+1;
    end
    i3=1;
    i4=1;
    
    for i=1:1:p;      %�����任
        if rem(i,2)==1
            outdata4(i)=outdataI(i3);
            i3=i3+1;
        end
        if rem(i,2)==0
            outdata4(i)=outdataQ(i4);
            i4=i4+1;
        end
    end
    
    
   
    set4_origin = outdata4;
    baotou_demod(3,:) = set4_origin(1,1:p_baotou);
    
    %-----------------------------------------------------------------------------------
    s7 =reshape(datareturn4,32,[]);
    s8=[s7(:,33:end)];
    s9 = fft(s8,32,1);
    s10 = reshape(s9,1,[]);
    
    %���
    I1=s10.*zaibo1;
    Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
    [b,a]=butter(jieshu,Wc,'low');
    I2=filter(b,a,I1);
    
    j=1;
    for iii=jg/2:jg:p*jg/2;
        if I2(iii)>=0;
            outdataI(j)=1;
        else if I2(iii)<0;
                outdataI(j)=-1;
            end
        end
        j=j+1;
    end
    
    Q1=s10.*zaibo2;    %Q·
    Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
    [d,c]=butter(jieshu,Wc,'low');
    Q2=filter(d,c,Q1);
    
    
    j=1;
    for iii=jg/2:jg:p*jg/2;
        if Q2(iii)>=0;
            outdataQ(j)=1;
        else if Q2(iii)<0;
                outdataQ(j)=-1;
            end
        end
        j=j+1;
    end
    i3=1;
    i4=1;
    
    for i=1:1:p;      %�����任
        if rem(i,2)==1
            outdata5(i)=outdataI(i3);
            i3=i3+1;
        end
        if rem(i,2)==0
            outdata5(i)=outdataQ(i4);
            i4=i4+1;
        end
    end
    
    
   
    set5_origin = outdata5;
    baotou_demod(4,:) = set5_origin(1,1:p_baotou);
    
    % ----------------------------------------------------------------------------------
    s7 =reshape(dataerror,32,[]);
    s8=[s7(:,33:end)];
    s9 = fft(s8,32,1);
    s10 = reshape(s9,1,[]);
    
    %���
    I1=s10.*zaibo1;
    Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
    [b,a]=butter(jieshu,Wc,'low');
    I2=filter(b,a,I1);
    
    j=1;
    for iii=jg/2:jg:p*jg/2;
        if I2(iii)>=0;
            outdataI(j)=1;
        else if I2(iii)<0;
                outdataI(j)=-1;
            end
        end
        j=j+1;
    end
    
    Q1=s10.*zaibo2;    %Q·
    Wc=ditong*f1/f2;                                          %��ֹƵ�� 2*fk/f2
    [d,c]=butter(jieshu,Wc,'low');
    Q2=filter(d,c,Q1);
    
    
    j=1;
    for iii=jg/2:jg:p*jg/2;
        if Q2(iii)>=0;
            outdataQ(j)=1;
        else if Q2(iii)<0;
                outdataQ(j)=-1;
            end
        end
        j=j+1;
    end
    i3=1;
    i4=1;
    
    for i=1:1:p;      %�����任
        if rem(i,2)==1
            outdata2(i)=outdataI(i3);
            i3=i3+1;
        end
        if rem(i,2)==0
            outdata2(i)=outdataQ(i4);
            i4=i4+1;
        end
    end
    
    
    errororigin=(sum(abs(indata-outdata2))/length(indata)/2);
    outdata2_real = outdata2(1,p_baotou+1:p);
    set2=reshape(outdata2_real,size_1(1,1),size_1(1,2));
    
    
    %------------------------------------------------------------------------------------------------------������λУ��ģ��
    set_zong = [set1_origin;
                set3_origin;
                set4_origin;
                set5_origin;];
    set_zong(1,p+1) = sum(abs(baotou_demod(1,:)-baotou_cop));
    set_zong(2,p+1) = sum(abs(baotou_demod(2,:)-baotou_cop));
    set_zong(3,p+1) = sum(abs(baotou_demod(3,:)-baotou_cop));
    set_zong(4,p+1) = sum(abs(baotou_demod(4,:)-baotou_cop));
    
    set_zong(:,p+2) = i_zdeofdmd;
    set_zong(:,p+3) = j_zdeofdmx;
    
    [xunzhao_v,xunzhao_t] = min(set_zong(:,p+1));
    [xunzhao_k,xunzhao_c] = max(set_zong(:,p+1));
    set_zong(:,p+4) = xunzhao_t;
    set_realorigin_1(i_mark,:) = set_zong(xunzhao_t,:);
        
%     set_realorigin_2 = set_zong(xunzhao_c,:);
%     set_realorigin_2 = -1*set_realorigin_2;
%     error5=(sum(abs(indata-set_realorigin_2))/length(indata)/2);
%     set_realqubaotou_2 = set_realorigin_2(1,p_baotou+1:p);
%     set_real_2 = reshape(set_realqubaotou_2,size_1(1,1),size_1(1,2));
    
    i_mark = i_mark + 1;
    end

end

 [xunzhao_v,xunzhao_t] = min(set_realorigin_1(:,p+1))
 set_trueorigin = set_realorigin_1(xunzhao_t,:);
 
 i_zdeofdmd_real = set_trueorigin(1,p+2);
 i_zdeofdmx_real = set_trueorigin(1,p+3);
 
 ZZZ_real = complex(cplex(set_trueorigin(1,p+4),1)*z_huanyuan_ofdmd(i_zdeofdmd_real,:), cplex(set_trueorigin(1,p+4),2)*z_huanyuan_ofdmx(i_zdeofdmx_real));
 
 set_realsignal = set_trueorigin(1,1:p);
 errorafter=(sum(abs(indata-set_realsignal))/length(indata)/2);
 set_realqubaotou_1 = set_trueorigin(1,p_baotou+1:p);
 set_real_1 = reshape(set_realqubaotou_1,size_1(1,1),size_1(1,2));
%-------------------------------------------------------------------------------------��ͼģ�飨Ƶ��

% [pinlv,fuzhi]=frequen(s,f2); %qpskƵ��ͼ
% figure
% plot(pinlv,fuzhi);
% title('qpskƵ��ͼ')

[pinlv,fuzhi]=frequen(ofdm_real,f2); %ofdmƵ��ͼ
figure
plot(pinlv,fuzhi);
title('ofdmƵ��ͼ')

[pinlv,fuzhi]=frequen(inoise,f2); %ofdmƵ��ͼ
figure
plot(pinlv,fuzhi);
title('����Ƶ��ͼ')

[pinlv,fuzhi]=frequen(datanoise_real,f2); %ofdmƵ��ͼ
figure
plot(pinlv,fuzhi);
title('�����ź�Ƶ��ͼ')

[pinlv,fuzhi]=frequen(ZZZ_real,f2); %ofdmƵ��ͼ
figure
plot(pinlv,fuzhi);
title('�����ź�Ƶ��ͼ')

%------------------------------------------------------------------------------------------��ʱ��

figure;
subplot(2,2,1);imshow(tu2);title('ԭʼͼ��');
subplot(2,2,2);imshow(set2);title('������ͼ��');
subplot(2,2,3);imshow(set_real_1);title('����ͼ��');

figure;
imshow(tu2);
title('ԭʼͼ��');

figure;
imshow(set2);
title('������ͼ��');

figure;
imshow(set_real_1);
title('����ͼ��');




